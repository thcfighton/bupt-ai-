import numpy as np  # 导入NumPy库，用于处理数组和矩阵操作

class MaxPool2d():
    def __init__(self, K_size, stride=1):
        # 构造函数，初始化最大池化层的参数
        self.K_size = K_size  # 池化核大小
        self.stride = stride  # 池化步幅

    def forward(self, input_tensor):
        # 正向传播函数，对输入的张量进行最大池化操作
        batch_size, in_C, in_H, in_W = input_tensor.shape  # 获取输入张量的形状（批大小，输入通道数，输入高度，输入宽度）
        self.d_in = np.zeros(input_tensor.shape)  # 初始化反向传播梯度张量
        self.batch_size = batch_size  # 记录批大小
        self.out_H = int((in_H - self.K_size) / self.stride) + 1  # 计算输出张量的高度
        self.out_W = int((in_W - self.K_size) / self.stride) + 1  # 计算输出张量的宽度
        self.out_C = in_C  # 输出通道数与输入通道数相同
        out_tensor = np.zeros((batch_size, self.out_C, self.out_H, self.out_W))  # 初始化输出张量
        for i in range(batch_size):
            one_input = input_tensor[i]  # 获取单个输入样本
            for c in range(self.out_C):
                for h in range(self.out_H):
                    for w in range(self.out_W):
                        vert_start = h * self.stride  # 计算垂直方向的起始位置
                        vert_end = vert_start + self.K_size  # 计算垂直方向的结束位置
                        horiz_start = w * self.stride  # 计算水平方向的起始位置
                        horiz_end = horiz_start + self.K_size  # 计算水平方向的结束位置
                        input_slice = one_input[c, vert_start:vert_end, horiz_start:horiz_end]  # 提取池化区域
                        out_tensor[i, c, h, w] = np.max(input_slice)  # 在池化区域内找到最大值并放入输出张量
                        max_place = np.where(one_input[c, vert_start:vert_end, horiz_start:horiz_end] == out_tensor[i, c, h, w])  # 找到最大值的位置
                        self.d_in[i, c, vert_start:vert_end, horiz_start:horiz_end][max_place] = 1  # 标记最大值在反向传播中的位置

        return out_tensor  # 返回最大池化后的输出张量

    def gradient(self, d_out):
        # 反向传播函数，计算最大池化层的梯度
        for i in range(self.batch_size):
            for c in range(self.out_C):
                for h in range(self.out_H):
                    for w in range(self.out_W):
                        vert_start = h * self.stride  # 计算垂直方向的起始位置
                        vert_end = vert_start + self.K_size  # 计算垂直方向的结束位置
                        horiz_start = w * self.stride  # 计算水平方向的起始位置
                        horiz_end = horiz_start + self.K_size  # 计算水平方向的结束位置
                        self.d_in[i, c, vert_start:vert_end, horiz_start:horiz_end] *= d_out[i, c, h, w]  # 根据输出梯度更新输入梯度
        return self.d_in  # 返回输入梯度

if __name__ == '__main':
    a = np.random.randint(1, 5, 64).reshape(2, 2, 4, 4)  # 随机生成一个输入张量
    print(a)
    pool_max = MaxPool2d(2, 2)  # 创建一个最大池化层对象
    out, _ = pool_max.forward(a)  # 使用最大池化层进行正向传播
    print(out)  # 打印最大池化后的输出张量
    h = pool_max.gradient(np.ones(a.shape))  # 使用最大池化层进行反向传播，输入为全1梯度
    print(h)  # 打印输入梯度
