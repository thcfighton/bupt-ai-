import numpy as np

def normalize(X):
    epsilon = 1e-5
    mean = np.mean(X)
    variance = np.var(X)
    X_normalized = (X - mean) / (np.sqrt(variance + epsilon))

    # Min-Max 归一化
    if ((np.max(X_normalized) - np.min(X_normalized)) != 0):
        X_normalized = (X_normalized - np.min(X_normalized)) / (np.max(X_normalized) - np.min(X_normalized))

    # 均值方差归一化
    X_normalized = (X_normalized - 0.5) / 0.5

    return X
if __name__ == '__main__':
    X = np.array([1.,2,100])
    print(normalize(X))